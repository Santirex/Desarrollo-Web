package co.edu.javeriana.libreria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibreriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
