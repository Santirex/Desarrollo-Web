package com.example.editorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EditorialServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
